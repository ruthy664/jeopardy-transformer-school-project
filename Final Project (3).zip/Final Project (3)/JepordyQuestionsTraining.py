# Jepordy Questions Topic Classifier

# Imports
import tensorflow as tf
import numpy as np
import string
import pickle
import en_core_web_md
nlp = en_core_web_md.load()


# Get data and weights
# Load Model
model = keras.models.load_model("data/model/jeopardy_transformer.keras")
# Load dictionary
with open('data/model/num2topic.pkl', 'rb') as file:
    num2topic = pickle.load(file)


# Find the topic
def find_topic(question):
    # Remove punctuation
    for p in string.punctuation:
        question = question.replace(p, "")

    # Embed the question
    X = np.zeros((40, 300), dtype=np.float32)
    doc = nlp(question)
    for i, t in enumerate(doc[:40]):  # truncate if too long
        if not t.is_space:
            X[i] = t.vector

    # Get the model prediction
    probs = model.predict(tf.expand_dims(X,axis=0))
    
    topic_num = np.argmax(probs)
    topic = num2topic.get(topic_num)
    
    return topic


# Play Jepordy
print("Let's play jepordy! Give me a question and I will predict the topic. Enter 'end' to finish.")

i = 1
question = input(f"Question {i}:").lower().strip()

while (question != "end"):
    topic = find_topic(question)
    print(f"You're topic is {topic}!")
    
    i+=1
    question = input(f"Question {i}:").lower().strip()

print("Thank you for playing!")